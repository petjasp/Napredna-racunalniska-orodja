﻿#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>

int main() {
    // Odpre datoteko
    std::ifstream indata("podatki.txt");

    // Preverimo ali je datoteka odprta, saj mora biti v isti mapi, kot je program!
    if (!indata.is_open()) {
        std::cerr << "Napaka pri odpiranju datoteke." << std::endl;
        return 1; // Vrne error, ki se izpiše na zaslonu.
    }

    // Prebere prvo vrstico, kjer je zapisano število točk.
    int numValues;
    indata >> numValues;

    // Ustvarimo dvo dimenzionalne vektorje imenovane data, v katere v prvo spremenljivko shranimo vrednost x, v drugo pa f(x).
    std::vector<std::pair<double, double>> data;

    // Preberemo ID točke, x vrednost in f(x) vrednost iz datoteke.
    for (int i = 0; i < numValues; ++i) {
        int id;
        double x, fx;
        char colon; // da lahko preberemo ':' znak v datoteki
        indata >> id >> colon >> x >> fx;
        data.push_back(std::make_pair(x, fx)); //Dobimo vektorje oblike [x, f(x)].
    }

    // Računanje odvodov.
    for (int i = 0; i < numValues; ++i) {
        double derivative;

        if (i == 0) {
            // Odvod skrajne leve točke izračunamo po metodi naprej. Vrednost x in f(x) pa kličemo z ukazom '.first oziroma .second', ker 
            //smo prej uporabili _pair ukaz.
            derivative = (-3 * data[i].second + 4 * data[i + 1].second - data[i + 2].second) / (2 * (data[i + 1].first - data[i].first));
        }
        else if (i == numValues - 1) {
            // Odvod skrajne desne točke (zadnje točke) po metodi nazaj.
            derivative = (3 * data[i].second - 4 * data[i - 1].second + data[i - 2].second) / (2 * (data[i].first - data[i - 1].first));
        }
        else {
            // Centralna diferenčna shema za vse ostale odvode.
            derivative = (data[i + 1].second - data[i - 1].second) / (2 * (data[i + 1].first - data[i].first));
        }

        std::cout << "Odvod v tocki X = " << data[i].first << ": " << derivative << std::endl;
    }

    return 0;
}
