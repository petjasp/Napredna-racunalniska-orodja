﻿#include <vector>
#include <iostream>
#include <fstream>
#include <cmath>
#include <string>
#include <sstream>
#define _USE_MATH_DEFINES
#include <algorithm>
#include <chrono>
#include <ctime>
#include <omp.h>

int deltaX = 1;// m
int deltaY = 1;// m
int k = 24;// W/mK

//funkcija za preverjanje sosednosti.
//vektor node_i_neighbours je podan z &, da ga lahko spreminjamo.
int preveri(std::vector<int>& node_i_neighbours,double x_obravnavano_vozl, double y_obravnavano_vozl, double x_sosed, double y_sosed, int sosednje_vozlisce) {

    int pozicija = -1;
    if ((x_obravnavano_vozl - x_sosed) < 1e-9
        && (x_obravnavano_vozl - x_sosed) > -1e-9) {
        // sosednje vozlišče se nahaja vertikalno
        //preverimo ali spodaj - zgoraj
        if ((y_obravnavano_vozl - y_sosed) > 0)
            // se nahaja spodaj - 2
             pozicija = 2;
        else
            // se nahaja zgoraj - 4
             pozicija = 4;
    }

    else if ((y_obravnavano_vozl - y_sosed) < 1e-9 &&
        (y_obravnavano_vozl - y_sosed) > -1e-9) {
        // sosednje vozlišče se nahaja horizontalno
        // preverimo ali levo - desno
        if ((x_obravnavano_vozl - x_sosed) > 0)
            // se nahaja levo - 1
            pozicija = 1;
        else
            // se nahaja desno - 3
             pozicija = 3;
    }

    else {
        // Ce vozlišči nista poravnani vertikalno ali
        // horizontalno ne storimo ničesar
        pozicija = -1;
    }

        // v kolikor smo dobili eno izmed sosednjih vrednosti
        // 1, 2, 3, 4
    if (pozicija != -1) {
        node_i_neighbours[pozicija-1] = sosednje_vozlisce;
    }
    return 0;
}

//funkcija za:iskanje vozlišč na robu in predpisavanje robnega pogoja
int sortiraj_robne_pogoje(const std::vector<int> vrednosti_prestopa_toplote,
    const std::vector<int> vrednosti_robnih_pogojev,
    const std::vector<int> tipi_robnih_pogojev, 
    const std::vector<std::vector<int>> vozlisca_robnih_pogojev,
    int node_id,int& tip_robnega_pogoja, int& vrednost, int& vrednost_prestopa) {

     for (int robni_pogoj_id = 0; robni_pogoj_id < 5; ++robni_pogoj_id)
     {
        std::vector<int> vozlisca_v_trenutnem_rp = vozlisca_robnih_pogojev[robni_pogoj_id];

        for (int id_vozlisce_rp = 0; id_vozlisce_rp < vozlisca_v_trenutnem_rp.size(); ++id_vozlisce_rp) {
            int vozlisce_v_trenutnem_rp = vozlisca_v_trenutnem_rp[id_vozlisce_rp];
            if (node_id == vozlisce_v_trenutnem_rp) {
                tip_robnega_pogoja = tipi_robnih_pogojev[robni_pogoj_id];
                vrednost = vrednosti_robnih_pogojev[robni_pogoj_id];
                vrednost_prestopa = vrednosti_prestopa_toplote[robni_pogoj_id];
            }
        }
     }
    return 0;
}


int main()
{
    //Odpre datoteko
    std::ifstream indata("primer4mreza.txt");

    //preverimo ali se je datoteka odprla
    if (!indata.is_open()) {
        std::cout << "Napaka pri odpiranju datoteke." << std::endl;
        return 1;
    }

    //beremo prvo vrstico datoteke
    std::string line;
    std::getline(indata, line);
    std::istringstream labelStream(line);
    std::string label;
    int stTock;

    // izluščimo ime in število točk
    if (!(labelStream >> label >> stTock)) {
        std::cerr << "Error extracting label and number." << std::endl;
        return 1;
    }
    std::cout << label << " = " << stTock << std::endl;

    //beremo točke
    std::vector<double> xkoord;
    std::vector<double> ykoord;
    std::vector<double> IDtock;

    for (int i = 0; i < stTock; i++) {
        int id;
        double x, y;
        char vejica;
        indata >> id >> vejica >> x >> vejica >> y;
        xkoord.push_back(x);
        ykoord.push_back(y);
        IDtock.push_back(id);

       // std::cout << id << "---" << x << "---" << y << std::endl; //za sprotno preverjanje
    }

    //BRANJE CELIC
    //prva vrstica
    std::string s2;
    std::getline(indata, s2);
    std::getline(indata, s2);
    std::getline(indata, s2);

    std::istringstream labelStream2(s2);
    std::string label2;
    int stCell;

    if (!(labelStream2 >> label2 >> stCell)) {
        std::cerr << "error" << std::endl;
        return 1;
    }
   std::cout << label2 << " = " << stCell << std::endl;

   // beremo celice
    std::vector<double> IDcell;
    std::vector<double> cellA;
    std::vector<double> cellB;
    std::vector<double> cellC;
    std::vector<double> cellD;

    for (int i = 0; i < stCell; i++) {
        int id2;
        double a, b,c,d;
        char vejica;
        indata >> id2 >> vejica >> a >> vejica >> b >> vejica >> c >> vejica >> d;
        IDcell.push_back(id2);
        cellA.push_back(a);
        cellB.push_back(b);
        cellC.push_back(c);
        cellD.push_back(d);

      //std::cout << id2 << "--" << a << "--" << "--" << b << "--" << c << "--" << d << std::endl;
    }

    //Matrika celic
    std::vector<std::vector<int>> matrikacell;
    for (int i = 0; i < stCell; ++i) {
        std::vector<int> column;
        column.push_back(cellA[i]);
        column.push_back(cellB[i]);
        column.push_back(cellC[i]);
        column.push_back(cellD[i]);
        matrikacell.push_back(column);
    }

    //za preverit kaksno celico
    std::cout << "First Vector: ";
    for (int element : matrikacell[0]) {
        std::cout << element << " ";
    }
    std::cout << std::endl;

    //----------------BRANJE ROBNIH POGOJEV------------------
    //prvi robni pogoj
    std::string s3,s4;
    std::getline(indata, s3);
    std::getline(indata, s3);
    std::getline(indata, s3);
    std::getline(indata, s3);
    std::getline(indata, s4);

    std::istringstream labelStream3(s4);
    std::string label3;
    int rp1;

    if (!(labelStream3 >> label3 >> rp1)) {
        std::cerr << "error" << std::endl;
        return 1;
    }
    std::cout <<"1" << label3 << " = " << rp1 << std::endl;

    //branje 1. rp
    std::string st1rp_str;
    std::getline(indata, st1rp_str);
    int st1rp = std::stoi(st1rp_str);
    std::vector<int> rp1_tockeV;
    for (int i = 0; i < st1rp; i++) {
        int rp1t;
        indata >> rp1t;

        rp1_tockeV.push_back(rp1t);
    }

    //drugi robni pogoj
    std::string s5, s6;
    std::getline(indata, s5);
    std::getline(indata, s5);
    std::getline(indata, s5);
    std::getline(indata, s6);

    std::istringstream labelStream4(s6); //labelStream4 je najprej shranjen kot stream
    std::string label4;
    int rp2;

    if (!(labelStream4 >> label4 >> rp2)) {
        std::cerr << "error" << std::endl;
        return 1;
    }
    std::cout << "2" << label4 << " = " << rp2 << std::endl;

   // branje 2. rp
    std::string rp2_st_t;
    std::vector<int> rp2_tockeV;
    std::getline(indata, rp2_st_t);
    int st2rp = std::stoi(rp2_st_t);
    for (int i = 0; i < st2rp; i++) {
        int rp2t;
        indata >> rp2t;

        rp2_tockeV.push_back(rp2t);
    }
   // std::cout << "rp2_tocke[1] = " << rp2_tockeV[1] << std::endl;

    // 3 robni pogoj
    std::string s7;
    std::getline(indata, s7);
    std::getline(indata, s7);
    std::getline(indata, s7);
    std::getline(indata, s7);
 

    std::istringstream labelStream5(s7);
    std::string label5;
    int rp3;

    if (!(labelStream5 >> label5  >> rp3)) {
        std::cerr << "error" << std::endl;
        return 1;
    }
    std::cout << "3" << label5 << " = " << rp3 << std::endl;

    // branje 3. rp
    std::string rp3_st_t;
    std::vector<int> rp3_tockeV;
    std::getline(indata, rp3_st_t);
    int st3rp = std::stoi(rp3_st_t);
    for (int i = 0; i < st3rp; i++) {
        int rp3t;
        indata >> rp3t;

        rp3_tockeV.push_back(rp3t);
    }
   // std::cout << "rp3_tocke[1] = " << rp3_tockeV[1] << std::endl;


    //4.robni pogoj
    std::string s9;
    std::getline(indata, s9);
    std::getline(indata, s9);
    std::getline(indata, s9);
    std::getline(indata, s9);

    std::istringstream labelStream6(s9);
    std::string label6;
    int rp4;

    if (!(labelStream6 >> label6 >>  label6  >> rp4)) {
        std::cerr << "error" << std::endl;
        return 1;
    }
    std::cout << "4 toplotni " << label6 << " = " << rp4 << std::endl;

    //branje 4.rp
    std::string rp4_st_t;
    std::vector<int> rp4_tockeV;
    std::getline(indata, rp4_st_t);
    int st4rp = std::stoi(rp4_st_t);
    for (int i = 0; i < st4rp; i++) {
        int rp4t;
        indata >> rp4t;

        rp4_tockeV.push_back(rp4t);
    }
    //std::cout << "rp4_tocke[1] = " << rp4_tockeV[1] << std::endl;
 

    //5.robni pogoj
    std::string s10;
    std::getline(indata, s10);
    std::getline(indata, s10);
    std::getline(indata, s10);
    std::getline(indata, s10);
   // std::cout << s9  << std::endl;

    std::istringstream labelStream7(s10);
    std::string label7;
    int rp5;

    if (!(labelStream7 >> label7 >> label7 >> rp5)) {
        std::cerr << "error" << std::endl;
        return 1;
    }
    std::cout << "5 toplotni " << label7 << " = " << rp5 << std::endl;

    //branje 5.rp
    std::string rp5_st_t;
    std::vector<int> rp5_tockeV;
    std::getline(indata, rp5_st_t);
    //std::cout << rp5_st_t << std::endl;
    int st5rp = std::stoi(rp5_st_t);
    for (int i = 0; i < st5rp; i++) {
        int rp5t;
        indata >> rp5t;

        rp5_tockeV.push_back(rp5t);
    }
  //  std::cout << "rp5_tocke[1] = " << rp5_tockeV[1] << std::endl;
    
   // sestava matrik
    std::vector<std::vector<int>> vozlisca_robnih_pogojev;
    vozlisca_robnih_pogojev.push_back(rp1_tockeV);
    vozlisca_robnih_pogojev.push_back(rp2_tockeV);
    vozlisca_robnih_pogojev.push_back(rp3_tockeV);
    vozlisca_robnih_pogojev.push_back(rp4_tockeV);
    vozlisca_robnih_pogojev.push_back(rp5_tockeV);


    //ostali vektorji
    std::vector<int> tipi_robnih_pogojev = {0,0,0,1,1};
    std::vector<int>vrednosti_robnih_pogojev = {300,50,150,0,0};
    std::vector<int> vrednosti_prestopa_toplote = { -1,-1,-1,-1,-1 };
   
    //--------------------DATOTEKA JE SEDAJ PREBRANA!-----------------------
    //VEKTORJI in MATRIKE: xkoord, ykoord, matrikacell,rp1,rp2,rp3,rp4,rp5,rp1_tockeV,rp2_tockeV,rp3_tockeV,rp4_tockeV,rp5_tockeV, vozlisca_robnih_pogojev
   
    //2. PRIPRAVA MATRIKE A IN VEKTORJA b
   //iskanje sosedov vozlišč
    std::vector<std::vector<int>> sosednja_vozlisca;
    //std::cout << matrikacell[1] << std::endl;
    for (int node_id = 0; node_id < stTock; ++node_id) {//iteracija po vozliščih
        std::vector<int> node_i_neighbours = { -1,-1,-1,-1 };

        for (int nd = 0; nd < stCell; ++nd) {

            std::vector<int> trenutna_celica = matrikacell[nd];

            int vozlisce1 = trenutna_celica[0];
            int vozlisce2 = trenutna_celica[1];
            int vozlisce3 = trenutna_celica[2];
            int vozlisce4 = trenutna_celica[3];

            //ugotovimo ali se vozlisce nahaja v celici
            if (node_id == vozlisce1 || node_id == vozlisce2 || node_id == vozlisce3 || node_id == vozlisce4) {

                for (int vozl = 0; vozl < 4; ++vozl) {
                    int sosednje_vozlisce = trenutna_celica[vozl];

                    if (sosednje_vozlisce != node_id) {
                        double x_obravnavano_vozl = xkoord[node_id];
                        double y_obravnavano_vozl = ykoord[node_id];
                        double x_sosed = xkoord[sosednje_vozlisce];
                        double y_sosed = ykoord[sosednje_vozlisce];

                        //kličemo zunanjo funkcijo
                        preveri(node_i_neighbours,x_obravnavano_vozl, y_obravnavano_vozl, x_sosed, y_sosed, sosednje_vozlisce);

                    }
                }
            }
        }
        // Dodamo trenutni vektor v matriko
        sosednja_vozlisca.push_back(node_i_neighbours);

    }
    
    //-------------------------2.2.del: GRADNJA MATRIKE A IN VEKTORJA b-----------------------------------------
    // matrika sosednjih vozlisc = "sosednja_vozlisca"

    // naredimo matriko A iz ničel velikosti št vozlišč
    std::vector<std::vector<double>> A(stTock, std::vector<double>(stTock, 0));
    std::vector<double> b(stTock,0);

    for (int node_id = 0; node_id < stTock; ++node_id) {
        std::vector<int> sosedi = sosednja_vozlisca[node_id];
        int levi_sosed = sosedi[0];
        int spodnji_sosed = sosedi[1];
        int desni_sosed = sosedi[2];
        int zgornji_sosed = sosedi[3];

        //ali je vozlišče na robu in kakšen je robni pogoj
        if (levi_sosed != -1 && spodnji_sosed != -1 && desni_sosed != -1 && zgornji_sosed != -1) {
            A[node_id][levi_sosed] = 1;
            A[node_id][spodnji_sosed] = 1;
            A[node_id][desni_sosed] = 1;
            A[node_id][zgornji_sosed] = 1;
            A[node_id][node_id] = -4;
        }
        else {
            int tip_robnega_pogoja;
            int vrednost;
            int vrednost_prestopa;

            sortiraj_robne_pogoje(vrednosti_prestopa_toplote, vrednosti_robnih_pogojev, tipi_robnih_pogojev, vozlisca_robnih_pogojev, 
                node_id, tip_robnega_pogoja, vrednost, vrednost_prestopa);
              
            if (tip_robnega_pogoja == 0) {
                A[node_id][node_id] = 1;
                b[node_id] = vrednost;
            }

            else if (tip_robnega_pogoja == 1) {
                int stevilo_sosedov = 0;
                for (int st = 0; st < 4; ++st) {
                    if (sosedi[st] != -1) {
                        stevilo_sosedov = stevilo_sosedov + 1;
                    }
                }

                if (stevilo_sosedov == 3) {
                    if (levi_sosed == -1) {
                        A[node_id][node_id] = A[node_id][node_id]-4;
                        A[node_id][desni_sosed] = A[node_id][desni_sosed]+2;
                        A[node_id][spodnji_sosed] = A[node_id][spodnji_sosed]+1;
                        A[node_id][zgornji_sosed] = A[node_id][zgornji_sosed]+1;
                        b[node_id] = -2 * (vrednost * deltaX/k);
                    }

                    if (desni_sosed == -1) {
                        A[node_id][node_id] = A[node_id][node_id] - 4;
                        A[node_id][levi_sosed] = A[node_id][levi_sosed] + 2;
                        A[node_id][spodnji_sosed] = A[node_id][spodnji_sosed] + 1;
                        A[node_id][zgornji_sosed] = A[node_id][zgornji_sosed] + 1;
                        b[node_id] = -2 * (vrednost * deltaX / k);
                    }

                    if (spodnji_sosed == -1) {
                        A[node_id][node_id] = A[node_id][node_id] - 4;
                        A[node_id][zgornji_sosed] = A[node_id][zgornji_sosed] + 2;
                        A[node_id][levi_sosed] = A[node_id][levi_sosed] + 1;
                        A[node_id][desni_sosed] = A[node_id][desni_sosed] + 1;
                        b[node_id] = -2 * (vrednost * deltaX / k);
                    }

                    if (zgornji_sosed == -1) {
                        A[node_id][node_id] = A[node_id][node_id] - 4;
                        A[node_id][spodnji_sosed] = A[node_id][spodnji_sosed] + 2;
                        A[node_id][levi_sosed] = A[node_id][levi_sosed] + 1;
                        A[node_id][desni_sosed] = A[node_id][desni_sosed] + 1;
                        b[node_id] = -2 * (vrednost * deltaX / k);
                    }                 
                }
            }

            else if (tip_robnega_pogoja == 2) {
                int stevilo_sosedov = 0;
                for (int st = 0; st < 4; ++st) {
                    if (sosedi[st] != -1) {
                        stevilo_sosedov = stevilo_sosedov + 1;
                    }
                }
                if (stevilo_sosedov == 3) {
                    if (levi_sosed == -1) {
                        A[node_id][node_id] = A[node_id][node_id] - 2 * (vrednost_prestopa * deltaX / k + 2);
                        A[node_id][desni_sosed] = A[node_id][desni_sosed] + 2;
                        A[node_id][spodnji_sosed] = A[node_id][spodnji_sosed] + 1;
                        A[node_id][zgornji_sosed] = A[node_id][node_id] + 1;
                        b[node_id] = b[node_id] - 2 * vrednost_prestopa * deltaX * vrednost / k;
                    }
                    if (desni_sosed == -1) {
                        A[node_id][node_id] = A[node_id][node_id] - 2 * (vrednost_prestopa * deltaX / k + 2);
                        A[node_id][levi_sosed] = A[node_id][levi_sosed] + 2;
                        A[node_id][spodnji_sosed] = A[node_id][spodnji_sosed] + 1;
                        A[node_id][zgornji_sosed] = A[node_id][zgornji_sosed] + 1;
                        b[node_id] = b[node_id] -2 * vrednost_prestopa * deltaX * vrednost / k;
                    }
                    if (spodnji_sosed == -1) {
                        A[node_id][node_id] = A[node_id][node_id] - 2 * (vrednost_prestopa * deltaX / k + 2);
                        A[node_id][levi_sosed] = A[node_id][levi_sosed] + 1;
                        A[node_id][desni_sosed] = A[node_id][desni_sosed] + 1;
                        A[node_id][zgornji_sosed] = A[node_id][zgornji_sosed] + 2;
                        b[node_id] = - 2 * vrednost_prestopa * deltaX * vrednost / k;
                    }
                    if (zgornji_sosed == -1) {
                        A[node_id][node_id] = A[node_id][node_id] - 2 * (vrednost_prestopa * deltaX / k + 2);
                        A[node_id][levi_sosed] = A[node_id][levi_sosed] + 1;
                        A[node_id][desni_sosed] = A[node_id][desni_sosed] + 1;
                        A[node_id][spodnji_sosed] = A[node_id][spodnji_sosed] + 2;
                        b[node_id] = - 2 * vrednost_prestopa * deltaX * vrednost / k;
                    }
                }
            }
        }
    }

    //---------------SEDAJ IMAMO ZAPISANO MATRIKO A in vektor b-------------
    //--------------------SLEDI REŠEVANJE SISTEMA ENAČB---------------------
    std::cout << "zacetek resevanja" << std::endl;

    std::vector<int> T(stTock, 300); //za začetno temperaturo izberemo 300°C


    auto start_time = std::chrono::high_resolution_clock::now(); //začnemo meriti čas

#pragma omp parallel //paralelno programiranje
    {
        for (int iitt = 0; iitt < 1000; iitt++) {

#pragma omp for

            for (int jj = 0; jj < stTock; jj++) {
                double d = b[jj];

                // Uporabimo pointerje za pohitritev branja vrstiv v matriki in vektorju
                const double* A_row = A[jj].data(); //const pove, da se brani podatki ne bodo spreminjali
                const int* T_ptr = T.data();

                for (int ii = 0; ii < stTock; ii++) {
                    if (jj != ii) {
                        d -= A_row[ii] * T_ptr[ii];
                    }
                }
#pragma opm critical
                {
                    T[jj] = d / A[jj][jj];
                }
            }
        }
    }

    auto end_time = std::chrono::high_resolution_clock::now(); //končamo merjenje časa
    std::chrono::duration<double> time_duration = end_time - start_time;
    std::cout << "Time of Gauss-Seidel: " << time_duration.count() << " seconds" << std::endl;

    std::cout << "zadnja tenperatura" << T[2000] << std::endl;
    std::cout << "konec resevanja" << std::endl;

    //-----------VEKTOR T[] JE NAŠA REŠITEV--------
    
    //----------shranjevanje v vtk format-----------
    //xkoord, ykoord, matrikacell, stCell, stTock, T

    std::ofstream out("output_test.vtk"); //odpremo novo datoteko za mrezo

    out << "# vtk DataFile Version 3.0\n";
    out << "Test datoteke\n"; // lahko daš poljubno ime
    out << "ASCII\n";
    out << "DATASET UNSTRUCTURED_GRID\n";

    out << "POINTS " << stTock << " float\n";

    //zapisemo koordinate x, y, z
    for (int i = 0; i < stTock; i++)
    {
        out << xkoord[i] << " " << ykoord[i] << " 0" << '\n';
    }

    out << "\n";

    //----------------------------------------------------------
    out << "CELLS " << stCell << " " << stCell * 5 << "\n";

    for (int i_cell=0; i_cell<stCell; i_cell++)
    {
        // Prva stevilka (4) pove, koliko elementov je se v vrstici 
        out << "4" << " " << matrikacell[i_cell][0] << " " << matrikacell[i_cell][1] << " " <<
            matrikacell[i_cell][2] << " " << matrikacell[i_cell][3] << '\n';
    }

    out << "\n";

    out << "CELL_TYPES " << stCell << "\n";
    for (int i_cell = 0; i_cell < stCell; i_cell++)
    {
        // kvadrat je definiran s stevilko 9,
        out << "9" << '\n';
    }

    out << "\n";
    //-----------------------------------------------------
    // Da definiramo vrednosti za vizualizacijo na vozliscih moramo
    // uporabiti kljucno besedo "POINT_DATA"
    out << "POINT_DATA " << stTock << "\n";
    out << "SCALARS T float 1\n"; 
    out << "LOOKUP_TABLE default\n";

    // nato naredimo iteracijo po vektorju, kjer imamo vrednosti za vizualizacijo in jih zapisemo
    for (int i_point = 0; i_point < stTock; i_point++) out << T[i_point] <<'\n';

    

    out.close();
    //----------------------------------------------------------
    //SHRANJEVANJE MATRIKE A IN VEKTORJA b v .txt DATOTEKO ZA REŠEVANJE V MATEMATICI
     // shranjevanje matrike A
    std::ofstream matrixFile("matrika_A.txt");
    for (int i = 0; i < stTock; i++) {
        std::vector<double> vrsta_A = A[i];
        for (int ele = 0; ele < stTock; ele++) {
                matrixFile << vrsta_A[ele] << " ";
            }
            matrixFile << "\n";
        }
        matrixFile.close();
    
        // shranjevanje vektorja b
    std::ofstream vectorFile("vektor_b.txt");
        
            for (const auto& elem : b) {
                vectorFile << elem << '\n';
            }
            vectorFile.close();

        // shranjevanje vektorja x
     std::ofstream vectorFile2("vektor_x.txt");

            for (const auto& elem : xkoord) {
                vectorFile2 << elem << '\n';
            }
            vectorFile2.close();


         // shranjevanje vektorja y
     std::ofstream vectorFile3("vektor_y.txt");

            for (const auto& elem : ykoord) {
                vectorFile3 << elem << '\n';
            }
            vectorFile3.close();

    return 0;

}

